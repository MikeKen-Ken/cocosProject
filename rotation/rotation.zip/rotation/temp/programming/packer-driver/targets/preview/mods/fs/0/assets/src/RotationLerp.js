System.register(["__unresolved_0", "cc", "bezier-js"], function (_export, _context) {
  "use strict";

  var _reporterNs, _cclegacy, _decorator, Component, Node, v3, CCFloat, tween, Quat, Bezier, _dec, _dec2, _dec3, _class, _class2, _descriptor, _descriptor2, _temp, _crd, ccclass, property, RotationLerp;

  function _initializerDefineProperty(target, property, descriptor, context) { if (!descriptor) return; Object.defineProperty(target, property, { enumerable: descriptor.enumerable, configurable: descriptor.configurable, writable: descriptor.writable, value: descriptor.initializer ? descriptor.initializer.call(context) : void 0 }); }

  function _assertThisInitialized(self) { if (self === void 0) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return self; }

  function _inheritsLoose(subClass, superClass) { subClass.prototype = Object.create(superClass.prototype); subClass.prototype.constructor = subClass; _setPrototypeOf(subClass, superClass); }

  function _setPrototypeOf(o, p) { _setPrototypeOf = Object.setPrototypeOf || function _setPrototypeOf(o, p) { o.__proto__ = p; return o; }; return _setPrototypeOf(o, p); }

  function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

  function _applyDecoratedDescriptor(target, property, decorators, descriptor, context) { var desc = {}; Object.keys(descriptor).forEach(function (key) { desc[key] = descriptor[key]; }); desc.enumerable = !!desc.enumerable; desc.configurable = !!desc.configurable; if ('value' in desc || desc.initializer) { desc.writable = true; } desc = decorators.slice().reverse().reduce(function (desc, decorator) { return decorator(target, property, desc) || desc; }, desc); if (context && desc.initializer !== void 0) { desc.value = desc.initializer ? desc.initializer.call(context) : void 0; desc.initializer = undefined; } if (desc.initializer === void 0) { Object.defineProperty(target, property, desc); desc = null; } return desc; }

  function _initializerWarningHelper(descriptor, context) { throw new Error('Decorating class property failed. Please ensure that ' + 'proposal-class-properties is enabled and runs after the decorators transform.'); }

  function _reportPossibleCrUseOfBezier(extras) {
    _reporterNs.report("Bezier", "bezier-js", _context.meta, extras);
  }

  return {
    setters: [function (_unresolved_) {
      _reporterNs = _unresolved_;
    }, function (_cc) {
      _cclegacy = _cc.cclegacy;
      _decorator = _cc._decorator;
      Component = _cc.Component;
      Node = _cc.Node;
      v3 = _cc.v3;
      CCFloat = _cc.CCFloat;
      tween = _cc.tween;
      Quat = _cc.Quat;
    }, function (_bezierJs) {
      Bezier = _bezierJs.Bezier;
    }],
    execute: function () {
      _crd = true;

      _cclegacy._RF.push({}, "5d7fc7IpYtLloMl6PeNYHM5", "RotationLerp", undefined);

      ccclass = _decorator.ccclass;
      property = _decorator.property;

      _export("RotationLerp", RotationLerp = (_dec = ccclass('RotationLerp'), _dec2 = property(Node), _dec3 = property(CCFloat), _dec(_class = (_class2 = (_temp = /*#__PURE__*/function (_Component) {
        _inheritsLoose(RotationLerp, _Component);

        function RotationLerp() {
          var _this;

          for (var _len = arguments.length, args = new Array(_len), _key = 0; _key < _len; _key++) {
            args[_key] = arguments[_key];
          }

          _this = _Component.call.apply(_Component, [this].concat(args)) || this;

          _initializerDefineProperty(_assertThisInitialized(_this), "lerpNode", _descriptor, _assertThisInitialized(_this));

          _initializerDefineProperty(_assertThisInitialized(_this), "speed", _descriptor2, _assertThisInitialized(_this));

          return _this;
        }

        var _proto = RotationLerp.prototype;

        _proto.start = function start() {
          this.getRoadList();
        };

        _proto.getRoadList = function getRoadList() {
          var bezier1 = new (_crd && Bezier === void 0 ? (_reportPossibleCrUseOfBezier({
            error: Error()
          }), Bezier) : Bezier)([v3(0, 0, 0), v3(-10, 2, -10), v3(0, 4, -10)]);
          var bezier2 = new (_crd && Bezier === void 0 ? (_reportPossibleCrUseOfBezier({
            error: Error()
          }), Bezier) : Bezier)([v3(0, 4, -10), v3(10, 2, -5), v3(0, 0, 0)]);
          var bezier1List = bezier1.getLUT(20);
          bezier1List.pop();
          var list = bezier1List.concat(bezier2.getLUT(20));
          var v3List = list.map(function (point) {
            return v3(point.x, point.y, point.z);
          });
          console.log(v3List);
          this.flyRole(v3List);
        };

        _proto.flyRole = function flyRole(list) {
          var _this2 = this;

          this.lerpNode.position = list[0];
          var tw = tween(this.lerpNode);
          var startQuat = new Quat();
          this.lerpNode.getRotation(startQuat);
          var curPosition;
          var nextPosition;
          var direction;
          var duration; //* 在贝塞尔曲线点之间进行插值

          var _loop = function _loop(index) {
            var curQuat = new Quat();
            var nextQuat = new Quat();
            curPosition = list[index - 1];
            nextPosition = list[index];
            direction = nextPosition.clone().subtract(curPosition).normalize();
            duration = direction.length() / _this2.speed; //* 根据物体的direction和up，获取四元数

            Quat.fromViewUp(nextQuat, direction, v3(0, 1, 0));
            tw.to(duration, {
              position: nextPosition
            }, {
              //* ratio：tween的插值比率
              onUpdate: function onUpdate(target, ratio) {
                curQuat.set(startQuat).slerp(nextQuat, ratio); // curQuat.set(startQuat).lerp(nextQuat, ratio);

                _this2.lerpNode.setRotation(curQuat);
              },
              onComplete: function onComplete() {
                _this2.lerpNode.getRotation(startQuat);
              }
            });
          };

          for (var index = 1; index < list.length; index++) {
            _loop(index);
          }

          tw.call(function () {
            _this2.flyRole(list);
          });
          tw.start();
        };

        return RotationLerp;
      }(Component), _temp), (_descriptor = _applyDecoratedDescriptor(_class2.prototype, "lerpNode", [_dec2], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function initializer() {
          return null;
        }
      }), _descriptor2 = _applyDecoratedDescriptor(_class2.prototype, "speed", [_dec3], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function initializer() {
          return 0.001;
        }
      })), _class2)) || _class));

      _cclegacy._RF.pop();

      _crd = false;
    }
  };
});
//# sourceMappingURL=RotationLerp.js.map