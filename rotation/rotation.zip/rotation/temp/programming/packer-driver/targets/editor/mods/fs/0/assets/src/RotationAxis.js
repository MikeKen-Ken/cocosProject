System.register(["cc"], function (_export, _context) {
  "use strict";

  var _cclegacy, _decorator, Component, Node, systemEvent, SystemEvent, v3, Quat, Vec3, CCFloat, _dec, _dec2, _dec3, _dec4, _class, _class2, _descriptor, _descriptor2, _descriptor3, _temp, _crd, ccclass, property, RotationAxis;

  function _initializerDefineProperty(target, property, descriptor, context) { if (!descriptor) return; Object.defineProperty(target, property, { enumerable: descriptor.enumerable, configurable: descriptor.configurable, writable: descriptor.writable, value: descriptor.initializer ? descriptor.initializer.call(context) : void 0 }); }

  function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

  function _applyDecoratedDescriptor(target, property, decorators, descriptor, context) { var desc = {}; Object.keys(descriptor).forEach(function (key) { desc[key] = descriptor[key]; }); desc.enumerable = !!desc.enumerable; desc.configurable = !!desc.configurable; if ('value' in desc || desc.initializer) { desc.writable = true; } desc = decorators.slice().reverse().reduce(function (desc, decorator) { return decorator(target, property, desc) || desc; }, desc); if (context && desc.initializer !== void 0) { desc.value = desc.initializer ? desc.initializer.call(context) : void 0; desc.initializer = undefined; } if (desc.initializer === void 0) { Object.defineProperty(target, property, desc); desc = null; } return desc; }

  function _initializerWarningHelper(descriptor, context) { throw new Error('Decorating class property failed. Please ensure that ' + 'proposal-class-properties is enabled and runs after the decorators transform.'); }

  return {
    setters: [function (_cc) {
      _cclegacy = _cc.cclegacy;
      _decorator = _cc._decorator;
      Component = _cc.Component;
      Node = _cc.Node;
      systemEvent = _cc.systemEvent;
      SystemEvent = _cc.SystemEvent;
      v3 = _cc.v3;
      Quat = _cc.Quat;
      Vec3 = _cc.Vec3;
      CCFloat = _cc.CCFloat;
    }],
    execute: function () {
      _crd = true;

      _cclegacy._RF.push({}, "1aad4TNB4JI5Kuz6H+dmzyF", "RotationAxis", undefined);

      ({
        ccclass,
        property
      } = _decorator);

      _export("RotationAxis", RotationAxis = (_dec = ccclass('RotationAxis'), _dec2 = property(Node), _dec3 = property(CCFloat), _dec4 = property(Node), _dec(_class = (_class2 = (_temp = class RotationAxis extends Component {
        constructor(...args) {
          super(...args);

          _initializerDefineProperty(this, "rotationNode", _descriptor, this);

          _initializerDefineProperty(this, "rotationScale", _descriptor2, this);

          _initializerDefineProperty(this, "targetAxis", _descriptor3, this);

          _defineProperty(this, "tempQuat", new Quat());

          _defineProperty(this, "tempV3", v3());

          _defineProperty(this, "targetPosition", v3());
        }

        onload() {
          this.targetPosition = this.targetAxis.worldPosition;
        }

        start() {
          systemEvent.on(SystemEvent.EventType.TOUCH_MOVE, this.onTouchMove, this);
        }

        onTouchMove(touch) {
          const delta = touch.getDelta();
          const axis = Vec3.UP;
          const radian = delta.x * this.rotationScale;
          const curPosition = this.rotationNode.worldPosition; //* 获取旋转的四元数

          Quat.fromAxisAngle(this.tempQuat, axis, radian);
          Vec3.subtract(this.tempV3, curPosition, this.targetPosition); //* 旋转向量

          Vec3.transformQuat(this.tempV3, this.tempV3, this.tempQuat); //* 得到旋转后的node位置

          Vec3.add(this.tempV3, this.targetPosition, this.tempV3);
          this.rotationNode.setWorldPosition(this.tempV3);
          const curQuat = this.rotationNode.worldRotation;
          Quat.rotateAround(this.tempQuat, curQuat, axis, radian);
          this.rotationNode.setWorldRotation(this.tempQuat);
        }

      }, _temp), (_descriptor = _applyDecoratedDescriptor(_class2.prototype, "rotationNode", [_dec2], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      }), _descriptor2 = _applyDecoratedDescriptor(_class2.prototype, "rotationScale", [_dec3], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return 0.01;
        }
      }), _descriptor3 = _applyDecoratedDescriptor(_class2.prototype, "targetAxis", [_dec4], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      })), _class2)) || _class));

      _cclegacy._RF.pop();

      _crd = false;
    }
  };
});
//# sourceMappingURL=RotationAxis.js.map