System.register(["__unresolved_0", "cc", "bezier-js"], function (_export, _context) {
  "use strict";

  var _reporterNs, _cclegacy, _decorator, Component, Node, v3, CCFloat, tween, Quat, Bezier, _dec, _dec2, _dec3, _class, _class2, _descriptor, _descriptor2, _temp, _crd, ccclass, property, RotationLerp;

  function _initializerDefineProperty(target, property, descriptor, context) { if (!descriptor) return; Object.defineProperty(target, property, { enumerable: descriptor.enumerable, configurable: descriptor.configurable, writable: descriptor.writable, value: descriptor.initializer ? descriptor.initializer.call(context) : void 0 }); }

  function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

  function _applyDecoratedDescriptor(target, property, decorators, descriptor, context) { var desc = {}; Object.keys(descriptor).forEach(function (key) { desc[key] = descriptor[key]; }); desc.enumerable = !!desc.enumerable; desc.configurable = !!desc.configurable; if ('value' in desc || desc.initializer) { desc.writable = true; } desc = decorators.slice().reverse().reduce(function (desc, decorator) { return decorator(target, property, desc) || desc; }, desc); if (context && desc.initializer !== void 0) { desc.value = desc.initializer ? desc.initializer.call(context) : void 0; desc.initializer = undefined; } if (desc.initializer === void 0) { Object.defineProperty(target, property, desc); desc = null; } return desc; }

  function _initializerWarningHelper(descriptor, context) { throw new Error('Decorating class property failed. Please ensure that ' + 'proposal-class-properties is enabled and runs after the decorators transform.'); }

  function _reportPossibleCrUseOfBezier(extras) {
    _reporterNs.report("Bezier", "bezier-js", _context.meta, extras);
  }

  return {
    setters: [function (_unresolved_) {
      _reporterNs = _unresolved_;
    }, function (_cc) {
      _cclegacy = _cc.cclegacy;
      _decorator = _cc._decorator;
      Component = _cc.Component;
      Node = _cc.Node;
      v3 = _cc.v3;
      CCFloat = _cc.CCFloat;
      tween = _cc.tween;
      Quat = _cc.Quat;
    }, function (_bezierJs) {
      Bezier = _bezierJs.Bezier;
    }],
    execute: function () {
      _crd = true;

      _cclegacy._RF.push({}, "5d7fc7IpYtLloMl6PeNYHM5", "RotationLerp", undefined);

      ({
        ccclass,
        property
      } = _decorator);

      _export("RotationLerp", RotationLerp = (_dec = ccclass('RotationLerp'), _dec2 = property(Node), _dec3 = property(CCFloat), _dec(_class = (_class2 = (_temp = class RotationLerp extends Component {
        constructor(...args) {
          super(...args);

          _initializerDefineProperty(this, "lerpNode", _descriptor, this);

          _initializerDefineProperty(this, "speed", _descriptor2, this);
        }

        start() {
          this.getRoadList();
        }

        getRoadList() {
          const bezier1 = new (_crd && Bezier === void 0 ? (_reportPossibleCrUseOfBezier({
            error: Error()
          }), Bezier) : Bezier)([v3(0, 0, 0), v3(-10, 2, -10), v3(0, 4, -10)]);
          const bezier2 = new (_crd && Bezier === void 0 ? (_reportPossibleCrUseOfBezier({
            error: Error()
          }), Bezier) : Bezier)([v3(0, 4, -10), v3(10, 2, -5), v3(0, 0, 0)]);
          const bezier1List = bezier1.getLUT(20);
          bezier1List.pop();
          const list = bezier1List.concat(bezier2.getLUT(20));
          const v3List = list.map(point => {
            return v3(point.x, point.y, point.z);
          });
          console.log(v3List);
          this.flyRole(v3List);
        }

        flyRole(list) {
          this.lerpNode.position = list[0];
          const tw = tween(this.lerpNode);
          const startQuat = new Quat();
          this.lerpNode.getRotation(startQuat);
          let curPosition;
          let nextPosition;
          let direction;
          let duration; //* 在贝塞尔曲线点之间进行插值

          for (let index = 1; index < list.length; index++) {
            const curQuat = new Quat();
            const nextQuat = new Quat();
            curPosition = list[index - 1];
            nextPosition = list[index];
            direction = nextPosition.clone().subtract(curPosition).normalize();
            duration = direction.length() / this.speed; //* 根据物体的direction和up，获取四元数

            Quat.fromViewUp(nextQuat, direction, v3(0, 1, 0));
            tw.to(duration, {
              position: nextPosition
            }, {
              //* ratio：tween的插值比率
              onUpdate: (target, ratio) => {
                curQuat.set(startQuat).slerp(nextQuat, ratio); // curQuat.set(startQuat).lerp(nextQuat, ratio);

                this.lerpNode.setRotation(curQuat);
              },
              onComplete: () => {
                this.lerpNode.getRotation(startQuat);
              }
            });
          }

          tw.call(() => {
            this.flyRole(list);
          });
          tw.start();
        }

      }, _temp), (_descriptor = _applyDecoratedDescriptor(_class2.prototype, "lerpNode", [_dec2], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      }), _descriptor2 = _applyDecoratedDescriptor(_class2.prototype, "speed", [_dec3], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return 0.001;
        }
      })), _class2)) || _class));

      _cclegacy._RF.pop();

      _crd = false;
    }
  };
});
//# sourceMappingURL=RotationLerp.js.map